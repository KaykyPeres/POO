public interface Suplemento {
    void recuperarVida();
}
