public interface Loja {
    void gastarMoedas();
    void comprarMoedas(int qtdMoedas);
}
