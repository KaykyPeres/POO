public interface Interacao {
    void interagir();
}
